-- Bovenaan server.lua: Hardcode de webhook (simpelste manier, vervang de URL!)
local DiscordWebhook = 'https://discord.com/api/webhooks/1467902997144145951/A2cG6hUDGRum4DARA5aTvIlkFLuvXBl3V5c-mBOxImxbpJkHX7jF8lLewjG_XeM13aAx'  -- Plak hier je Discord webhook URL

-- Require de QBX logger (importeert de module, server-only)
local logger = require '@qbx_core.modules.logger'

-- Voorbeeld: Log een event (bijv. player joining, pas aan naar jouw code)
AddEventHandler('stryv:giveJobReward', function()
    local src = source  -- Speler ID (altijd veilig ophalen)
    local playerName = GetPlayerName(src) or 'Onbekend'  -- Veilige fallback voor naam

    -- Stuur de log naar Discord (en fallback naar console via ox_lib)
    logger.log({
        source = playerName,          -- Bron: wie triggert het (speler naam)
        event = 'speler heeft een item ontvangen',      -- Event: korte titel voor Discord embed
        message = playerName .. ' heeft een prisonjob uitgevoerd en een item ontvangen.',  -- Bericht: details
        webhook = DiscordWebhook      -- Je hardcoded URL (optioneel, zonder = alleen console)
    })
end)


RegisterNetEvent('stryv:checkJobCooldown')
AddEventHandler('stryv:checkJobCooldown', function(jobKey)
    local src = source
    local Player = exports.qbx_core:GetPlayer(src)
    local now = GetGameTimer()
    local lastJobTimes = Player.PlayerData.metadata.lastJobTimes or {}
    local lastTime = lastJobTimes[jobKey] or 0
    if now - lastTime < Config.Cooldown then
        TriggerClientEvent('stryv:cooldownNotify', src)
        return
    end
    TriggerClientEvent('stryv:startJob', src, jobKey)
end)

RegisterNetEvent('stryv:setJobTime')
AddEventHandler('stryv:setJobTime', function(jobKey)
    local src = source
    local Player = exports.qbx_core:GetPlayer(src)
    local now = GetGameTimer()
    local lastJobTimes = Player.PlayerData.metadata.lastJobTimes or {}
    lastJobTimes[jobKey] = now
    Player.Functions.SetMetaData('lastJobTimes', lastJobTimes)
end)

RegisterNetEvent('stryv:giveJobReward')
AddEventHandler('stryv:giveJobReward', function(jobKey)
    local src = source
    local rewards = Config.Jobs[jobKey].rewards
    for _, reward in ipairs(rewards) do
        if math.random(1, 100) <= reward.chance then
            exports.ox_inventory:AddItem(src, reward.item, reward.count)
        end
    end
end)