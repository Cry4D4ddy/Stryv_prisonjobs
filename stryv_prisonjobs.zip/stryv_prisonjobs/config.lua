Config = {}

-- Lifer check
Config.IsLifer = function()
    local PlayerData = exports.qbx_core:GetPlayerData()
    return PlayerData.job.name == 'lifer'
end

-- Centrale start target (pas vector3 aan)
Config.StartTarget = {
    location = vec3(1775.55, 2550.61, 45.55),  -- VECTOR3: x, y, z (pas aan)
    icon = 'fas fa-briefcase',
    label = 'Start Prison Job',
    size = vector3(1.0, 1.0, 1.0),
    rotation = 0.0,
    debug = false
}

-- Job duur, cooldown
Config.JobDuration = 10000  -- 10 sec progress (pas aan voor sneller, bijv. 5000)
Config.Cooldown = 900000    -- 15 min (pas aan)

-- Jobs (pas vector3 voor locations (markers) en target_locations aan)
Config.Jobs = {
    kitchen = {
        label = 'Voedsel klaarmaken',
        animDict = 'anim@amb@business@coc@coc_unpack_cut_left@',  -- Chopping
        anim = 'coke_cut_v1_coccutter',
        flags = 1,
        minigameConfig = { difficulty = {'easy', 'easy', 'easy'}, keys = {'e'}, amount = 3 },
        locations = {
            vec3(1780.86, 2564.3, 44.67)
        },
        target_locations = {
            vec3(1780.88, 2565.0, 45.59)
        },
        rewards = {  
            {item = 'bread', count = 2, chance = 80},
            {item = 'water', count = 3, chance = 100},
            {item = 'fruit', count = 1, chance = 50}
        }
    },
    cleaning = {
        label = 'Binnenplaats poetsen',
        animDict = 'timetable@floyd@clean_kitchen@base',
        anim = 'base',
        flags = 1,
        minigameConfig = { difficulty = {'medium', 'easy', 'medium'}, keys = {'e'}, amount = 3 }, --aanpasbaar
        locations = {
            vec3(1771.98, 2545.52, 44.55),
            vec3(1746.43, 2535.09, 44.55),
            vec3(1747.17, 2514.08, 44.55),
            vec3(1720.45, 2524.38, 44.55),
            vec3(1712.58, 2502.09, 44.55),
            vec3(1693.04, 2482.03, 44.55),
            vec3(1665.51, 2493.89, 44.55),
            vec3(1636.53, 2504.1, 44.55),
            vec3(1655.3, 2527.1, 44.55),
            vec3(1656.8, 2541.3, 44.55),
            vec3(1644.54, 2560.71, 44.55),
            vec3(1671.73, 2562.04, 44.55),
            vec3(1703.18, 2563.89, 44.55),
            vec3(1737.71, 2550.35, 44.55),
            vec3(1765.49, 2559.71, 44.55)
        },
        target_locations = {
            vec3(1771.98, 2545.52, 44.55),
            vec3(1746.43, 2535.09, 44.55),
            vec3(1747.17, 2514.08, 44.55),
            vec3(1720.45, 2524.38, 44.55),
            vec3(1712.58, 2502.09, 44.55),
            vec3(1693.04, 2482.03, 44.55),
            vec3(1665.51, 2493.89, 44.55),
            vec3(1636.53, 2504.1, 44.55),
            vec3(1655.3, 2527.1, 44.55),
            vec3(1656.8, 2541.3, 44.55),
            vec3(1644.54, 2560.71, 44.55),
            vec3(1671.73, 2562.04, 44.55),
            vec3(1703.18, 2563.89, 44.55),
            vec3(1737.71, 2550.35, 44.55),
            vec3(1765.49, 2559.71, 44.55)
        },
        rewards = {
            {item = 'soap', count = 2, chance = 70},
            {item = 'sponge', count = 2, chance = 90},
            {item = 'disinfectant', count = 1, chance = 40}
        }
    },
    gardening = {
        label = 'Tuinieren',
        animDict = 'amb@world_human_gardener_plant@male@base',  -- Graven/planten anim
        anim = 'base',
        flags = 1,
        minigameConfig = { difficulty = {'easy', 'medium', 'easy'}, keys = {'e'}, amount = 4 },  -- Aanpasbaar
        locations = {  -- Markers vector3 (pas aan)
            vec3(1723.28, 2547.17, 44.55),
            vec3(1719.11, 2552.65, 44.55),
            vec3(1714.68, 2548.0, 44.55),
            vec3(1710.58, 2552.72, 44.55),
            vec3(1705.8, 2548.61, 44.55),
            vec3(1708.44, 2542.09, 44.55),
            vec3(1714.17, 2538.21, 44.55)
        },
        target_locations = {  -- Aparte targets vector3 (pas aan)
            vec3(1723.28, 2547.17, 44.55),
            vec3(1719.11, 2552.65, 44.55),
            vec3(1714.68, 2548.0, 44.55),
            vec3(1710.58, 2552.72, 44.55),
            vec3(1705.8, 2548.61, 44.55),
            vec3(1708.44, 2542.09, 44.55),
            vec3(1714.17, 2538.21, 44.55)
        },
        rewards = {
            {item = 'rope', count = 4, chance = 100},
            {item = 'seed', count = 2, chance = 80},
            {item = 'soil', count = 3, chance = 50}
        }
    },
    dishwashing = {
        label = 'Afwassen',
        animDict = 'timetable@maid@cleaning_surface@base',  -- Afwassen/poetsen anim
        anim = 'base',
        flags = 1,
        minigameConfig = { difficulty = {'easy', 'medium', 'easy'}, keys = {'e'}, amount = 3 },  -- Aanpasbaar minigame
        locations = {  -- VECTOR3 voor markers (zichtbaarheid, op grond - pas aan)
            vec3(1778.34, 2564.37, 44.67)  -- Voorbeeld 1 marker (bij wasbak) 
        },
        target_locations = {  -- APARTE VECTOR3 voor targets (interactie, hoger z - pas aan)
            vec3(1778.3, 2565.02, 45.57)   -- Voorbeeld 1 target
        },
        rewards = {  -- Loot voor afwas (pas aan)
            {item = 'rope', count = 1, chance = 100},
            {item = 'clean_dish', count = 3, chance = 80},
            {item = 'water', count = 2, chance = 50}
        }
    }
}