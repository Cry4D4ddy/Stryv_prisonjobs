local activeJob = nil
local lastJobTime = {}
local markers = {}
local workTargets = {}  -- Houd bij dynamische targets
local completedLocations = {}  -- Track voltooide locaties per job
local hasCompletedOne = false  -- Flag voor eerste succes

-- Functie voor anim spelen
local function PlayAnim(dict, anim, flags)
    lib.requestAnimDict(dict)
    TaskPlayAnim(PlayerPedId(), dict, anim, 8.0, -8.0, -1, flags, 0, false, false, false)
end

-- Stop anim
local function StopAnim(dict)
    ClearPedTasks(PlayerPedId())
    RemoveAnimDict(dict)
end

-- Teken markers voor zichtbaarheid (blauwe cirkels)
local function DrawMarkers()
    for i, loc in ipairs(markers) do
        if not completedLocations[i] then
            DrawMarker(1, loc.x, loc.y, loc.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.5, 0, 0, 255, 100, false, true, 2, false, nil, nil, false)  -- RGB 0,0,255 = blauw
        end
    end
end

-- Voeg dynamische work targets toe (blijven staan tot succes)
local function AddWorkTargets(jobKey, targetLocations)
    for i, loc in ipairs(targetLocations) do
        local targetId = exports.ox_target:addBoxZone({
            coords = loc,
            size = vector3(2.0, 2.0, 2.0),
            rotation = 0.0,
            debug = Config.Jobs[jobKey].debug,
            options = {
                {
                    name = 'work_' .. jobKey .. '_' .. i,
                    icon = 'fas fa-tools',
                    label = 'Werk hier (' .. Config.Jobs[jobKey].label .. ')',
                    canInteract = function()
                        return Config.IsLifer() and activeJob == jobKey and not completedLocations[i]
                    end,
                    distance = 2.0,
                    onSelect = function()
                        StartJobWork(jobKey, i, targetId)
                    end
                }
            }
        })
        workTargets[i] = targetId
    end
end

-- Verwijder alle work targets (alleen bij stop or complete)
local function RemoveWorkTargets()
    for _, targetId in pairs(workTargets) do
        exports.ox_target:removeZone(targetId)
    end
    workTargets = {}
end

-- Centrale start target (met stop optie)
exports.ox_target:addBoxZone({
    coords = Config.StartTarget.location,
    size = Config.StartTarget.size,
    rotation = Config.StartTarget.rotation,
    debug = Config.StartTarget.debug,
    options = {
        {
            name = 'prison_jobs_start',
            icon = Config.StartTarget.icon,
            label = Config.StartTarget.label,
            canInteract = function() return Config.IsLifer() and not activeJob end,
            distance = 1.5,
            onSelect = function()
                local menuOptions = {}
                for key, job in pairs(Config.Jobs) do
                    table.insert(menuOptions, { label = job.label, value = key })
                end
                local input = lib.inputDialog('Kies Job', {
                    { type = 'select', label = 'Welke job?', options = menuOptions, required = true }
                })
                if input then
                    local jobKey = input[1]
                    local now = GetGameTimer()
                    if lastJobTime[jobKey] and now - lastJobTime[jobKey] < Config.Cooldown then
                        lib.notify({ title = 'Wacht', description = 'Cooldown actief!', type = 'error' })
                        return
                    end
                    activeJob = jobKey
                    markers = Config.Jobs[jobKey].locations
                    completedLocations = {}  -- Reset voltooide locaties
                    hasCompletedOne = false  -- Reset flag
                    AddWorkTargets(jobKey, Config.Jobs[jobKey].target_locations)
                    lib.notify({ title = 'Gestart', description = Config.Jobs[jobKey].label .. ' gestart! Ga naar de markers.', type = 'success' })
                end
            end
        },
        {
            name = 'prison_jobs_stop',
            icon = 'fas fa-times',
            label = 'Stop Job',
            canInteract = function() return Config.IsLifer() and activeJob ~= nil end,
            distance = 1.5,
            onSelect = function()
                RemoveWorkTargets()
                markers = {}
                activeJob = nil
                completedLocations = {}
                hasCompletedOne = false
                lib.notify({ title = 'Gestopt', description = 'Job gestopt!', type = 'inform' })
            end
        }
    }
})

-- Thread voor markers
CreateThread(function()
    while true do
        if activeJob and markers then
            DrawMarkers()
        end
        Wait(0)
    end
end)

-- Functie om werk te starten (minigame, anim, progress, reward per werk)
function StartJobWork(jobKey, locationIndex, targetId)
    local job = Config.Jobs[jobKey]
    PlayAnim(job.animDict, job.anim, job.flags)

    -- Minigame
    local success = lib.skillCheck(job.minigameConfig.difficulty, job.minigameConfig.keys)
    if not success then
        StopAnim(job.animDict)
        lib.notify({ title = 'Mislukt', description = 'Minigame gefaald! Probeer opnieuw.', type = 'error' })
        return  -- Faal: target/marker blijft
    end

    if lib.progressBar({
        duration = Config.JobDuration,
        label = 'Werkt aan ' .. job.label .. '...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true }
    }) then
        StopAnim(job.animDict)
        TriggerServerEvent('stryv:giveJobReward', jobKey)

        -- Alleen voor 'cleaning' en 'gardening': verwijder en check complete
        if jobKey == 'cleaning' or jobKey == 'gardening' then
            lib.notify({ title = 'Succes', description = 'Ga naar de volgende plek!', type = 'inform' })
            completedLocations[locationIndex] = true  -- Markeer als voltooid
            exports.ox_target:removeZone(targetId)  -- Verwijder target bij succes
            workTargets[locationIndex] = nil

            -- Set cooldown na eerste succes
            if not hasCompletedOne then
                hasCompletedOne = true
                lastJobTime[jobKey] = GetGameTimer()
                lib.notify({ title = 'Cooldown Gestart', description = 'Je kunt deze job niet meer accepteren tot de cooldown voorbij is.', type = 'inform' })
            end

            -- Check of alle locaties voltooid
            local allCompleted = true
            for i = 1, #markers do
                if not completedLocations[i] then
                    allCompleted = false
                    break
                end
            end
            if allCompleted then
                RemoveWorkTargets()
                markers = {}
                activeJob = nil
                completedLocations = {}
                hasCompletedOne = false
                lib.notify({ title = 'Voltooid', description = 'Alle locaties gedaan! Cooldown gestart.', type = 'success' })
            end
        else
            -- Voor andere jobs: geen verwijder, geen complete check
            lib.notify({ title = 'Succes', description = 'Je kunt doorgaan!', type = 'inform' })
        end
    else
        StopAnim(job.animDict)
        lib.notify({ title = 'Geannuleerd', type = 'inform' })
    end
end