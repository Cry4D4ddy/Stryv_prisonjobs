fx_version 'cerulean'
game 'gta5'

author 'stryv'
description 'Prison jobs script'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'  -- This loads Config globally
}

dependencies {
    'ox_lib',
    'ox_target',
    'ox_inventory',
    'qbx_core'
}